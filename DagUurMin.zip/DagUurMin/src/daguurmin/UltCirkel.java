/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daguurmin;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author Dell
 */
public class UltCirkel extends JFrame{
    
}
class CirkelPaneel extends JPanel {
    private JTextField invoerVak;
    private int aantal;
    
public CirkelPaneel () {
    
}
}
