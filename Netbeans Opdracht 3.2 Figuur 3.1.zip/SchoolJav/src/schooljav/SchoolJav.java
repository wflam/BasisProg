/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schooljav;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author Dell
 */
public class SchoolJav extends JFrame {
    public static void main( String args[]) {
        JFrame frame = new SchoolJav ();
        frame.setSize( 400, 200);
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        frame.setTitle( " Voorbeeld 0301");
        frame.setContentPane( new Paneel() );
        frame.setVisible( true );
    }
}
//Het Paneel
class Paneel extends JPanel {
    private int a;
    private int b;
    private int antwoord;

public Paneel(){
    a = 174;
    b = 26;
    antwoord = a + b;
}

public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    //zet de waarden van a, b en antword op het scherm
    g.drawString( "Overzicht van de berekening:", 40, 20 );
    g.drawString( "a = " + a, 40, 40 );
    g.drawString( "b = " + b, 40, 60 );
    g.drawString( "De som is: " + antwoord, 40, 80 );
}
}